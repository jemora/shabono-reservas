
<head>

<title>Quienes Somos</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">






<style type="text/css">
<!--
.Estilo1 {font-size: 12px}
.Estilo9 {font-size: 10; font-family: Verdana, Arial, Helvetica, sans-serif; }
.Estilo10 {font-size: 10}
.Estilo14 {font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; }
.Estilo15 {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-weight: bold;
	font-size: 12px;
}
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--

function GP_popupConfirmMsg(msg) { //v1.0
  document.MM_returnValue = confirm(msg);
}
//-->
</script>
<link href="Level2_Verdana_Text.css" rel="stylesheet" type="text/css">
</head>

<body>
<table width="537" border="0" align="center" cellspacing="0">
  <tr>
    <td colspan="3" class="xbig">Gran Hotel </td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><span class="small">Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Donec  viverra sem aliquet urna. Sed ullamcorper faucibus nisl. Sed mollis  risus vel nisl. Donec faucibus vulputate erat. Nam commodo mi ac  ligula. Fusce pharetra, sapien eu auctor volutpat, arcu sapien interdum  justo, sit amet placerat sem nulla sit amet odio. Sed vestibulum  adipiscing metus. Nulla porttitor, massa eget faucibus euismod, nibh  ipsum varius erat, in fringilla ligula tortor at arcu. Fusce hendrerit,  lectus ac molestie vulputate, lorem lorem facilisis orci, ut fermentum  ligula ligula ac turpis. Donec elit metus, bibendum sed, cursus sit  amet, cursus lobortis, neque.</span></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td width="150"><img src="imagenes/hotel1.jpg" width="146" height="111"></td>
    <td width="150"><div align="center"><img src="imagenes/hotel2.jpg" width="146" height="111"></div></td>
    <td width="150"><div align="right"><img src="imagenes/hotel3.jpg" width="146" height="111"></div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3"><img src="imagenes/hotel4.gif" width="540" height="286"></td>
  </tr>
</table>
<p><br>
</p>
</body>
</html>

