<?
require_once('conector/conector.php');
$usuarios_sesion="autentificator";
$sql_host=$hostname;  // Host, nombre del servidor o IP del servidor Mysql.
$sql_usuario=$username;        // Usuario de Mysql
$sql_pass=$password;           // contrase�a de Mysql
$sql_db=$database;     // Base de datos que se usar�.
$sql_tabla="usuarios2"; // Nombre de la tabla que contendr� los datos de los usuarios
?>