
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>.....:::..</title>
<style type="text/css">
<!--
body {
	background-image: url();
}
.Estilo14 {color: #666666; font-size: 12px; }
.Estilo16 {color: #666666; font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; }
.Estilo4 {color: #666666; font-size: 12px; font-family: Verdana, Arial, Helvetica, sans-serif; font-weight: bold; }
-->
</style></head>



<div align="center">
<img src="imagenes/banne14.gif" width="607" height="30" /> <br />
<table width="566" border="1" align="center" cellspacing="0" bordercolor="#999999" bgcolor="#F4F4F4">
  <!--DWLayoutTable-->
  <tr>
    <td width="560" height="29" valign="top"><table width="560" border="0" align="center">
      <!--DWLayoutTable-->
      <tr>
        <td width="19" bgcolor="#F4F4F4"><span class="Estilo14"><a href="javascript:history.back(1)"><img src="imagenes/ico_3.gif" alt="Regresar" width="18" height="18" border="0" /></a></span></td>
        <td width="136" bgcolor="#F4F4F4"><span class="Estilo16">Regresar</span></td>
        <td width="364" bgcolor="#F4F4F4"><div align="right"></div></td>
        <td width="23" bgcolor="#F4F4F4"><div align="right"><a href="javascript: window.print()"></a></div></td>
      </tr>
    </table></td>
  </tr>
</table>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p>&nbsp;</p>
<p align="center"><span class="Estilo16">El Usuario se Actualizo Correctamente </span><br />
</p>
<p align="center">&nbsp;</p>
