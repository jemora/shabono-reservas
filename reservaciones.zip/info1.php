<style type="text/css">
<!--
.Estilo4 {font-size: 12px}
-->
</style>
<table width="601" border="1" align="center" cellspacing="0" bordercolor="#999999" bgcolor="#F4F4F4">
  <!--DWLayoutTable-->
  <tr>
    <td width="560" height="24" valign="top"><table width="601" border="0" align="right" cellspacing="0">
      <!--DWLayoutTable-->
      <tr>
        <td height="30" bgcolor="#F4F4F4"><form action="formulario_acompanante.php?&amp;codigo=<?php echo $codigo ?>&amp;multi=<?php echo $multi; ?>" method="post" name="form1" id="form1">
          <label>
          <input type="submit" name="Submit" value="     Agregar  Acompa&ntilde;antes      " />
          </label>
        </form></td>
        </tr>
    </table></td>
  </tr>
</table>
 