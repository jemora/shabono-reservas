
<head>

<title>lista de habitaciones</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">



</head>

<body>
<table width="0" border="0" align="right" cellspacing="0">
  <tr>
    <th scope="col"><a href="?&idgaleria=galeria"><img src="imagenes/banne22.gif" width="141" height="30" border="0"></a></th>
  </tr>
  <tr>
    <th scope="col"><?php				
           if ( $idgaleria  == 'galeria' )
			  {   include("visualizador_hab_galerias.php");  
                 } 
		   
				  ?></th>
  </tr>
</table>
</body>
</html>

