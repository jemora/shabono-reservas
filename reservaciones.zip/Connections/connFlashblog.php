<?php
$hostname_connFlashblog = "localhost";
$database_connFlashblog = "hotel";
$username_connFlashblog = "root";
$password_connFlashblog = "";
$connFlashblog= mysql_connect($hostname_connFlashblog, $username_connFlashblog, $password_connFlashblog) or die(mysql_error());
?>