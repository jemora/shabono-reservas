An excellent book on code generation and generative programming
by Jack Herrington. 