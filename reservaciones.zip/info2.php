<link href="Level2_Verdana_Text.css" rel="stylesheet" type="text/css" />
<style type="text/css">
<!--
.Estilo5 {
	color: #FF0000;
	font-size: 14px;
	font-weight: bold;
}
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
}
a:active {
	text-decoration: none;
}
-->
</style>
<table width="200" border="1" align="center" cellspacing="0" bordercolor="#000000">
  <tr>
    <td><table width="610" border="1" align="center" cellspacing="0" bordercolor="#7895AF">
      <tr>
        <td bgcolor="#7895AF"><strong>Reservaciones</strong></td>
      </tr>
      <tr>
        <td bgcolor="#FFFFFF"><table width="609" border="0">
          <!--DWLayoutTable-->
          <tr>
            <td width="603" height="186"> <div align="center" class="Estilo5"><img src="imagenes/atencion.jpg" width="63" height="55" /><br />
              Faltan Datos </div>
              <div align="center"><a href="habitacion.php?codigo=<? echo $_SESSION['doc2'] ?>">&lt;&lt; Regresar </a></div></td>
          </tr>
        </table>
              <p>&nbsp;</p></td>
      </tr>
    </table></td>
  </tr>
</table>
