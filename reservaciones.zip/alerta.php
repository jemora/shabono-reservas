
<head>

<title>Quienes Somos</title>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">






<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
body,td,th {
	font-family: Verdana, Arial, Helvetica, sans-serif;
	font-size: 12px;
}
-->
</style>
<script language="JavaScript" type="text/JavaScript">
<!--

function GP_popupConfirmMsg(msg) { //v1.0
  document.MM_returnValue = confirm(msg);
}
//-->
</script>
<link href="Level2_Verdana_Text.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.Estilo1 {
	color: #AF5700;
	font-weight: bold;
}
-->
</style>
</head>

<body>
<table width="537" border="0" align="center" cellspacing="0">
  <tr>
    <td width="535" class="xbig">&nbsp;</td>
  </tr>
  <tr>
    <td><div align="center"><img src="imagenes/atencion.jpg" width="63" height="55"></div></td>
  </tr>
  <tr>
    <td><div align="center" class="Estilo1">Acceso a Clientes Registrados </div></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<p><br>
</p>
</body>
</html>

