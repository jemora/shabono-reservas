<?php 

$men[1]="Se ha Actualizado el registro correctamente!!!";
$men[2]="Se ha modificado el registro correctamente!!!";
$men[3]="Se ha eliminado el registro correctamente!!!";

$mensaje1='<div align="center"><img src=imagenes/atencion.jpg width="63" height="55" /><br />
</div>
<table width="323" border="1" align="center" cellspacing="0" bordercolor="#000000">
  <tr> <th width="317" bgcolor="#FFFFCC" scope="col"><p><b><font face="Arial" color="#990000" size="2">      Fecha ya Registrada</font></b></p> </th></tr></table><p align="center"><a href="javascript:history.back(1)"><strong> Regresar';
  
  $mensaje11='<div align="center"><img src=imagenes/atencion.jpg width="63" height="55" /><br />
</div>
<table width="323" border="1" align="center" cellspacing="0" bordercolor="#000000">
  <tr> <th width="317" bgcolor="#FFFFCC" scope="col"><p><b><font face="Arial" color="#990000" size="2">      Error en Fechas</font></b></p> </th></tr></table><p align="center"><a href="javascript:history.back(1)"><strong> Regresar';
  
  $mensaje111='<div align="center"><img src=imagenes/atencion.jpg width="63" height="55" /><br />
</div>
<table width="323" border="1" align="center" cellspacing="0" bordercolor="#000000">
  <tr> <th width="317" bgcolor="#FFFFCC" scope="col"><p><b><font face="Arial" color="#990000" size="2">      No puede ser Ocupada </font></b></p> </th></tr></table><p align="center"><a href="javascript:history.back(1)"><strong> Regresar'; 
  
  
$mensaje2='<div align="center"><img src="imagenes/atencion.jpg" width="63" height="55" /><br /></div>
<table width="323" border="1" align="center" cellspacing="0" bordercolor="#000000">  <tr><th width="317" bgcolor="#FFFFCC" scope="col"><p><b><font face="Arial" color="#990000" size="2">      No Hay Caja Aperturada</font></b></p> </th></tr></table> <p align="center"><a href="javascript:history.back(1)"><strong> Regresar';
$mensaje3='<p align="center"><b><font face="Arial" color="#000066" size="2">Se ha registrado Correctamente</font></b><font color="#000066"></font></b></font></p><p align="center"><img src="imagenes/ico_5.gif" width="18" height="18" /></p>';

$mensaje_reservacion1='<strong><br /><br>No hay Reservaciones</strong>';
$mensaje_factura1='<strong><br /><br>No hay Facturas Registradas</strong>';
$mensaje_dia_cancelado='<strong><br /><br>No hay Facturas por Cancelarse</strong>';

// cuando se escribe una fecha superior a la del dia  usaremos este mensaje
$mensaje_caja_error='<table width="323" border="0" align="center" cellspacing="0" bordercolor="#000000"> <tr><th width="317" scope="col"><p><b><font face="Arial" color="#990000" size="2"><img src="imagenes/atencion.jpg" width="63" height="55" /></font></b></p></th> </tr> <tr> <th scope="col"><b><font color="#990000" size="2" face="Arial">Error en Fecha</font></b></th> 
</tr></table>';




$mensaje_caja_apertura='<table width="323" border="0" align="center" cellspacing="0" bordercolor="#000000"> <tr><th width="317" scope="col"><p><b><font face="Arial" color="#990000" size="2"><img src="imagenes/atencion.jpg" width="63" height="55" /></font></b></p></th> </tr> <tr><th scope="col"><b><font face="Arial" color="#990000" size="2">Caja  ya Aperturada</font></b></th> </tr></table>';

$mensaje_caja_apertura1='<table width="323" border="0" align="center" cellspacing="0" bordercolor="#000000">  <tr> <th width="317" scope="col"><table width="566" border="1" align="center" cellspacing="0" bordercolor="#999999" bgcolor="#F4F4F4">     <!--DWLayoutTable--> <tr>  <td width="560" height="24" valign="top"><table width="560" border="0" align="center" cellspacing="0"><!--DWLayoutTable--><tr><td width="19" bgcolor="#F4F4F4"><span class="Estilo14"><a href="javascript:history.back(1)"><img src="imagenes/ico_3.gif" alt="Regresar" width="18" height="18" border="0" /></a></span></td><td width="136" bgcolor="#F4F4F4"><span class="Estilo16">Regresar</span></td><td width="364" bgcolor="#F4F4F4"><div align="right"></div></td><td width="23" bgcolor="#F4F4F4"><div align="right"></div></td> </tr></table></td> </tr></table></th> </tr>  <tr><th scope="col"><b><font face="Arial" color="#990000" size="2"><img src="imagenes/atencion.jpg" width="63" height="55" /></font></b></th> </tr>
  <tr><th scope="col"><b><font face="Arial" color="#990000" size="2">Caja  ya Creada</font></b></th>  </tr></table>';

$mensaje_caja_apertura2;'No hay cajas Aperturadas';



$mensaje_caja_apertura3='<table width="323" border="0" align="center" cellspacing="0" bordercolor="#000000">  <tr> <th width="317" scope="col"><table width="566" border="1" align="center" cellspacing="0" bordercolor="#999999" bgcolor="#F4F4F4">     <!--DWLayoutTable--> <tr>  <td width="560" height="24" valign="top"><table width="560" border="0" align="center" cellspacing="0"><!--DWLayoutTable--><tr><td width="19" bgcolor="#F4F4F4"><span class="Estilo14"><a href="javascript:history.back(1)"><img src="imagenes/ico_3.gif" alt="Regresar" width="18" height="18" border="0" /></a></span></td><td width="136" bgcolor="#F4F4F4"><span class="Estilo16">Regresar</span></td><td width="364" bgcolor="#F4F4F4"><div align="right"></div></td><td width="23" bgcolor="#F4F4F4"><div align="right"></div></td> </tr></table></td> </tr></table></th> </tr>  <tr><th scope="col"><b><font face="Arial" color="#990000" size="2"><img src="imagenes/atencion.jpg" width="63" height="55" /></font></b></th> </tr>
  <tr><th scope="col"><b><font face="Arial" color="#990000" size="2">Caja  ya Creada</font></b></th>  </tr></table>';


$mensaje_caja_actualizacion;'<table width="323" border="0" align="center" cellspacing="0" bordercolor="#000000"> <tr><th width="317" scope="col"><b><font face="Arial" size="2">Caja actualizada Correctamente</font></b></th></tr></table>
';

?>
