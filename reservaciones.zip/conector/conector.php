<?php
$hostname = "localhost";
$database = "hotel";
$username = "root";
$password = "";
$connFlashblog = mysql_connect($hostname, $username, $password) or die(mysql_error());
?>

