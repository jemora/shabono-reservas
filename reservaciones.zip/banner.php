<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Documento sin t&iacute;tulo</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
}
-->
</style></head>

<body>
<table width="770" border="0" align="center" cellspacing="0">
  <tr>
    <th width="689" height="21" scope="col"><div align="left">
      <?php include("banner_principal.php");?>
    </div>    </th>
  </tr>
  <tr>
    <td><?php include("menu_hotel1.php");?></td>
  </tr>
</table>
</body>
</html>
