<form action="" method="get" name="form1">
<input name="boton" type="button" value="Imagenes" onClick="open('popup_empresas.php?txtImagen=txtImagen','PopUp','directories=no scrollbars=no resizable=no height=300,width=500 left=100')">
<input name="txtImagen" type="text" id="txtImagen">
</form>